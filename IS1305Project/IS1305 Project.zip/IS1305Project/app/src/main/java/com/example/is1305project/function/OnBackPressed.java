package com.example.is1305project.function;

public interface OnBackPressed {
    void onBackPressed();
}
